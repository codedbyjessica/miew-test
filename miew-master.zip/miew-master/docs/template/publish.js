/*global env: true */
'use strict';

var publish = require('jsdoc/templates/default/publish').publish;
exports.publish = publish;
