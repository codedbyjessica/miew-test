var Miew = require('..');
console.log(Miew.VERSION);
