import path from 'path';

export default {
  url: null, // 'http://miew.opensource.epam.com/master',
  localPath: path.resolve(__dirname, '../../build'),
  localPort: 8008,
  threshold: 1,
};
