module.exports = {
  root: false,

  parserOptions: {
    sourceType: 'module',
  },

  env: {
    'shared-node-browser': true,
    mocha: true,
  },

  rules: {
  },
};
