import {loaders} from './loaders';
import {parsers} from './parsers';

export default {
  loaders,
  parsers,
};
